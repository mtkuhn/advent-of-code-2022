package mkuhn.aoc

import readInput

fun main() {
    val input = readInput("Day${day}")
    println(day${day}part1(input))
    println(day${day}part2(input))
}

fun day${day}part1(input: List<String>): Int =
    1

fun day${day}part2(input: List<String>): Int =
    2